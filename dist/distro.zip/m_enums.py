_A='center'
class Align:LEFT='left';RIGHT='right';CENTER=_A;NONE=None
class IconAlign:LEFT='row';RIGHT='row-reverse';TOP='column';BOTTOM='column-reverse';NONE=''
class Events:CLICK='click'
class Justify:START='flex-start';END='flex-end';CENTER=_A;BETWEEN='space-between';AROUND='space-around';EVENLY='space-evenly';LEFT='left';RIGHT='right'